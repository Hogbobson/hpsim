#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 28 19:24:16 2019

@author: hogbobson
"""

def n_squared(ensemble):
    pass