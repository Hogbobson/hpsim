#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 28 19:36:44 2019

@author: hogbobson
"""

def constant_dt(value):
    return value

def courant():
    pass
