#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May 28 19:24:16 2019

@author: hogbobson
"""

class ntgrtr:
    def __init__(self):
        pass
    
    def n_squared(self, ensemble):
        pass