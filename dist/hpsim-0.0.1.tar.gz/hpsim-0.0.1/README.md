# hpsim
A (hopefully) high performance, modular simulator for everything from molecules to galaxy clusters.

v0.0.1:
Trying to setup the package. Internally I'm at 0.3.2 - I hope to have the package reach the same point soon.
